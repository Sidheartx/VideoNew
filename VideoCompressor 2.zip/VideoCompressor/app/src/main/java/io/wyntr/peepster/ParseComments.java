package io.wyntr.peepster;

/**
 * Created by Siddharth on 4/4/16.
 */
public class ParseComments {

    String comments;

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }
}