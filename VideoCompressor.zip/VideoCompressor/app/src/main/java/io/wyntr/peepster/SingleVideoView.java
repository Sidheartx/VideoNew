package io.wyntr.peepster;

/**
 * Created by Siddharth on 4/1/16.
 */

import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.widget.MediaController;
import android.widget.VideoView;



import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.widget.MediaController;
import android.widget.VideoView;

/**
 * Created by sagar_000 on 3/9/2016.
 */
public class SingleVideoView extends Activity {

    VideoView mVideoView = null;
    String phone;
    @Override
    protected void onCreate (Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        // Get the intent from ListViewAdapter
        Intent i = getIntent();
        // Get the intent from ListViewAdapter
        phone = i.getStringExtra("video");

        setContentView(R.layout.video_layout);
        mVideoView = (VideoView)findViewById(R.id.videoView);
        MediaController mediaController = new MediaController(this);
        mediaController.setAnchorView(mVideoView);
        // mVideoView.setMediaController(mediaController);
        mVideoView.setVideoPath(phone);
        mVideoView.start();

        mVideoView.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                finish();
            }
        });
    }
}
