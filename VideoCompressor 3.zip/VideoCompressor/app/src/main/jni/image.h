#ifndef image_h
#define image_h

#include <jni.h>

jint imageOnJNILoad(JavaVM *vm, void *reserved, JNIEnv *env);

#endif
